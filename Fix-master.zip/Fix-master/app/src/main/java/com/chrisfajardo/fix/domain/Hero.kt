package com.chrisfajardo.fix.domain

class Hero(val id: String, val name: String)