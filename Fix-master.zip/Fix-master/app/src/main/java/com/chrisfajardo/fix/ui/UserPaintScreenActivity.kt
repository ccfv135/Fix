package com.chrisfajardo.fix.ui

data class UserPaintScreenActivity(
    val name: String = "DEFAULT URL",
    val phone: String = "DEFAULT PHONE",
    val description: String = "DEFAULT DESC",
    val url: String = "DEFAULT URL_IMAGE"
)