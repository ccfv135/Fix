package com.chrisfajardo.fix.paintscreen

data class UserPaintScreen(val imageUrl:String = "DEFAULT URL",
                           val nombre:String = "DEFAULT NAME",
                           val descripcion:String = "DEFAULT DESC")