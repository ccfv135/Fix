package com.chrisfajardo.fix

class Hero(val id: String, val name: String)